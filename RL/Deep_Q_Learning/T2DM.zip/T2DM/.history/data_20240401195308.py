import os
import pandas as pd

# Directory where the .xlsx files are located
directory = '/home/fyyy0407/RL/Deep_Q_Learning/T2DM/'
equal=[]
for i in range(1,90):
    path=f"{directory}{i}.csv" 
    # Read the .csv file
    df = pd.read_csv(path)
    
    column4=df.columns[4]
    column2=df.columns[2]
    if column2==column4:
        equal.append(1)
  
    # Save the modified DataFrame back to a .csv file
    df.to_csv(path, index=False)
print(equal)



