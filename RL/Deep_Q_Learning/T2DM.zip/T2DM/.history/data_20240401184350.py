import os
import pandas as pd

# Directory where your .xlsx files are located
directory = '/home/fyyy0407/RL/Deep_Q_Learning/T2DM/'

# List all files in the directory and filter out non-xlsx files
xlsx_files = [f for f in os.listdir(directory) if f.endswith('.xlsx')]

# Sort the files by their current naming if needed (this depends on how you want to map the names to numbers)
xlsx_files.sort()

# Loop through the sorted .xlsx files, load them and save as .csv
for i, filename in enumerate(xlsx_files, start=1):
    # Load the xlsx file
    file_path = os.path.join(directory, filename)
    df = pd.read_excel(file_path)

    # Convert the xlsx file to a csv file
    new_filename = os.path.join(directory, f"{i}.csv")
    df.to_csv(new_filename, index=False)

    # Optionally, if you also want to delete the old .xlsx file, uncomment the following line
    # os.remove(file_path)
