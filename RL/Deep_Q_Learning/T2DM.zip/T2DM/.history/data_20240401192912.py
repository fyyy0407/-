import os
import pandas as pd

# Directory where the .xlsx files are located
directory = '/home/fyyy0407/RL/Deep_Q_Learning/T2DM/'
for i in range(1,90):
    path=f"{directory}{i}.csv" 
    # Read the .csv file
    df = pd.read_csv(path)
    
    print(len(df[0]))
    # Save the modified DataFrame back to a .csv file
    df.to_csv(path, index=False)



