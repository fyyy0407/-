import os
import pandas as pd

# Directory where the .xlsx files are located
directory = '/path/to/your/xlsx/files'

# Get a list of all .xlsx files in the directory
xlsx_files = [file for file in os.listdir(directory) if file.endswith('.xlsx')]

# Convert each .xlsx file to a .csv file
for index, file in enumerate(xlsx_files, start=1):
    # Construct the full file path
    file_path = os.path.join(directory, file)
    
    # Read the .xlsx file
    df = pd.read_excel(file_path)
    
    # Define the new .csv file name
    new_file_name = f"{index}.csv"
    new_file_path = os.path.join(directory, new_file_name)
    
    # Save the DataFrame as a .csv file
    df.to_csv(new_file_path, index=False)

    # Print out the new file path for confirmation
    print(f"Converted {file} to {new_file_path}")
