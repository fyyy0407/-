import os
import pandas as pd

# Directory where the .xlsx files are located
directory = '/home/fyyy0407/RL/Deep_Q_Learning/T2DM/'
for i in range(1,90):
    path=f"{directory}{i}.csv" 
    # Read the .csv file
    df = pd.read_csv(path)
    
    datalen=len(df[df.columns[0]])
    column=df[df.columns[2]]
    for i in range(0,datalen+1):
        if column[i] is None:
            column[i]=0
        else:
            column[i]=1
  
    # Save the modified DataFrame back to a .csv file
    df.to_csv(path, index=False)



