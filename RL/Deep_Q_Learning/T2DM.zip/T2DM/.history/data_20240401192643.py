import os
import pandas as pd

# Directory where the .xlsx files are located
directory = '/home/fyyy0407/RL/Deep_Q_Learning/T2DM/'
for i in range(1,90):
    path=f"{directory}{i}.csv" 
    # Read the .csv file
    df = pd.read_csv(path)
    columns_to_remove_indexes = [2, 3,5,8,9,10]  # assuming columns C and D are the 3rd and 4th columns

    # Remove the columns by index
    df.drop(df.columns[columns_to_remove_indexes], axis=1, inplace=True)


    # Save the modified DataFrame back to a .csv file
    df.to_csv(path, index=False)



